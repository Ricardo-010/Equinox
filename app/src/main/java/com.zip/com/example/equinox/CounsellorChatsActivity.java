package com.example.equinox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class CounsellorChatsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counsellor_chats);
        getSupportActionBar().hide();

        ArrayList<Integer> array = new ArrayList<>();
        array.add(1);
        array.add(12);
        array.add(16);
        array.add(10);

        ArrayList<Integer> array1 = new ArrayList<>();
        array1.add(1);
        array1.add(12);
        array1.add(10);
        for (int i= 0; i < array1.size(); i++){
            System.out.println(array.contains(array1.get(i)));
            //System.out.println(i);
        }
    }
}