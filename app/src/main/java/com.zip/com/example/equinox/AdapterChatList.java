package com.example.equinox;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterChatList extends RecyclerView.Adapter<viewHolderChatList> {
    ArrayList<String> patient_names;


    //A constructor to collect the message being sent
    public AdapterChatList(ArrayList<String> patient_names) {
        this.patient_names = patient_names;
    }

    @NonNull
    @Override
    public viewHolderChatList onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.users, parent, false);
        return new viewHolderChatList(view);//.linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolderChatList holder, int position) {
        holder.textView.setText(patient_names.get(position));
    }

    @Override
    public int getItemCount() {
        return patient_names.size();
    }
}

class viewHolderChatList extends RecyclerView.ViewHolder{
    TextView textView;

    //private AdapterChatList adapter;

    public viewHolderChatList(@NonNull View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.username);
    }
    /*
    public viewHolderChatList linkAdapter(AdapterChatList adapter){
        this.adapter = adapter;
        return this;
    }

     */
}
